-- Section1
SELECT MAX(salary) AS salary 
FROM employees
-- Section2
SELECT teams.name AS team, employees.name AS employee, my_table.my_salary AS salary 
FROM employees, (SELECT MAX(salary) AS my_salary, teams.id AS my_team 
	FROM teams, employees WHERE teams.id = employees.team_id GROUP BY my_team) AS my_table, teams
WHERE employees.team_id = my_table.my_team AND employees.salary = my_table.my_salary AND teams.id = my_table.my_team