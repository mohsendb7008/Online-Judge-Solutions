import consts


class Snake:

    dx = {'UP': 0, 'DOWN': 0, 'LEFT': -1, 'RIGHT': 1}
    dy = {'UP': -1, 'DOWN': 1, 'LEFT': 0, 'RIGHT': 0}

    def __init__(self, keys, game, pos, color, direction):
        self.keys = keys
        self.cells = [pos]
        self.game = game
        self.game.add_snake(self)
        self.color = color
        self.direction = direction
        game.get_cell(pos).set_color(color)

    def get_head(self):
        return self.cells[-1]

    def val(self, x):
        if x < 0:
            x += self.game.size
        if x >= self.game.size:
            x -= self.game.size
        return x

    def next_move(self):
        pos = self.val(self.get_head()[0] + Snake.dx[self.direction]), self.val(self.get_head()[1] + Snake.dy[self.direction])
        cell = self.game.get_cell(pos)
        if cell.color == consts.block_color:
            self.game.kill(self)
            return
        for snake in self.game.snakes:
            if pos in snake.cells:
                self.game.kill(self)
                return
        bonus = cell.color == consts.fruit_color
        self.cells.append(pos)
        cell.set_color(self.color)
        if not bonus:
            pos = self.cells.pop(0)
            cell = self.game.get_cell(pos)
            cell.set_color(consts.back_color)

    def handle(self, keys):
        for k in keys:
            if k in self.keys:
                direction = self.keys[k]
                if direction == 'UP' and self.direction == 'DOWN':
                    continue
                if direction == 'DOWN' and self.direction == 'UP':
                    continue
                if direction == 'LEFT' and self.direction == 'RIGHT':
                    continue
                if direction == 'RIGHT' and self.direction == 'LEFT':
                    continue
                self.direction = direction
                return
                    
