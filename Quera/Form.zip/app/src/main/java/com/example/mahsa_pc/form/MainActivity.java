package com.example.mahsa_pc.form;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

     private TextView errorMessage;
     private EditText nameInput;
     private EditText studentNumberInput;
     private EditText entranceYearInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        errorMessage = (TextView) findViewById(R.id.errorMessage);
        nameInput = (EditText) findViewById(R.id.nameInput);
        studentNumberInput = (EditText) findViewById(R.id.studentNumberInput);
        entranceYearInput = (EditText) findViewById(R.id.entranceYearInput);
    }

    public void submit(View it){
        errorMessage.setText(result());
    }

    private String result(){
        StringBuilder buffer = new StringBuilder();
        try {
            String name = nameInput.getText().toString();
            if(!(name.charAt(0) >= 'A' && name.charAt(0) <= 'Z'))
                buffer.append("name is invalid");
            String studentNumber = studentNumberInput.getText().toString();
            if(studentNumber.isEmpty())
                throw new Exception("Empty String.");
            Integer.valueOf(studentNumber);
            if(studentNumber.length() != 8) {
                if(!buffer.toString().equals(""))
                    buffer.append("\n");
                buffer.append("student number is invalid");
            }
            String entranceYear = entranceYearInput.getText().toString();
            if(entranceYear.isEmpty())
                throw new Exception("Empty String.");
            Integer.valueOf(entranceYear);
            if(!studentNumber.substring(0, 2).equals(entranceYear)) {
                if(!buffer.toString().equals(""))
                    buffer.append("\n");
                buffer.append("entrance year is invalid");
            }
            if(buffer.toString().equals(""))
                return "you submit successfully";
            return buffer.toString();
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }
}
