from bs4 import BeautifulSoup, Comment

class HTMLParser:

    @staticmethod
    def get(tag, output_arg):
        if output_arg == 'name':
            return tag.name
        if output_arg == 'string':
            return tag.get_text()
        if output_arg == 'class':
            return tag.attrs.get('class', [''])[0]
        if output_arg == 'id':
            return tag.attrs.get('id', '')

    def __init__(self, html_doc):
        self.html_doc = html_doc
        self.parser = BeautifulSoup(self.html_doc, 'html.parser')

    def set_html_doc(self, html_doc):
        self.html_doc = html_doc
        self.parser = BeautifulSoup(self.html_doc, 'html.parser')
    
    def find_first(self, output_arg, **finding_args):
        tag = self.parser.find(**finding_args)
        if not tag:
            raise Exception('No Such Tag')
        return HTMLParser.get(tag, output_arg)
        
    def find_all(self, n, output_arg, **finding_args):
        if n == 0:
            return []
        ans = list(map(lambda tag: HTMLParser.get(tag, output_arg), self.parser.find_all(**finding_args)[:n]))
        if ans:
            return ans
        raise Exception('No Such Tag')

    def find_parent(self, output_arg, **finding_args):
        tag = self.parser.find(**finding_args)
        if not tag:
            raise Exception('No Such Tag')
        return HTMLParser.get(tag.parent, output_arg)

    def find_grandparent(self, n, output_arg, **finding_args):
        tag = self.parser.find(**finding_args)
        if not tag:
            raise Exception('No Such Tag')
        try:
            for i in range(n):
                tag = tag.parent
            return HTMLParser.get(tag, output_arg)
        except:
            raise Exception('No Such Parent')

    def remove_comment(self, **finding_args):
        tag = self.parser.find(**finding_args)
        if not tag:
            raise Exception('No Such Tag')
        if not isinstance(tag.string, Comment):
            raise Exception('No Comments Found')
        tag.decompose()
        self.html_doc = self.parser.prettify()

    def remove_all_comments(self):
        tags = self.parser.find_all()
        for tag in tags:
            if isinstance(tag.string, Comment):
                tag.decompose()
        self.html_doc = self.parser.prettify()

    def remove_tag(self, **finding_args):
        tag = self.parser.find(**finding_args)
        if not tag:
            raise Exception('No Such Tag')
        tag.decompose()
        self.html_doc = self.parser.prettify()