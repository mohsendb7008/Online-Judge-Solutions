from person import Person, Consts
from math import floor


class Worker(Person):

    def __init__(self, name, age):
        super().__init__(name, age)
        self.job = "worker"

    def get_price(self):
        return floor(Consts.BASE_PRICE['worker'] * (Consts.MIN_AGE / self.age))

    def calc_life_cost(self):
        return floor(Consts.BASE_COST['worker'] * (self.age / Consts.MIN_AGE))

    def calc_income(self):
        return floor(Consts.BASE_INCOME['worker'][self.work_place.get_expertise()] * (Consts.MIN_AGE / self.age))
